let app = angular.module('myApp', ['ui.router', 'cp.ngConfirm']);

 //==================================================================================================================================               
 //==================================================================================================================================               
 app.controller('ctrlGlobal', function($scope, $http, $ngConfirm){
    // Obtem o tipo do usuário
    $http.get('../api/obterTipoUsuario.php').then(function(response) {
        if (response.data.status === 200) {
            $scope.userType = response.data.tipo;
            $scope.checkPermission(); // Correção: chama a função de checar permissão com $scope
        } else {
            console.log("Ocorreu um erro ao obter o tipo de usuário:", response.data.msg);
        }
    }).catch(function(error) {
        console.log("Ocorreu um erro ao obter o tipo do usuário:", error);
    });

    // Função para checar permissão
    $scope.checkPermission = function(permission) {
        if ($scope.userType === "admin") {
            return true;
        } else if ($scope.userType === "operador" && (permission === "produtos" || permission === "users" || permission === "cupom" || permission === "relatorioEstoque" || permission === "relatorioLucro")) {
            return false;
        }
        return false;
    }

    // Obtém o nome do usuário
    $http.get('../api/obterNomeUsuario.php').then(function(response) {
        $scope.nomeUsuario = response.data.nome;
    }).catch(function(error) {
        console.log("Ocorreu um erro ao obter o nome do usuário:", error);
    });


 //==================================================================================================================================               
 //==================================================================================================================================  
    // Faz o logout
    $scope.logout = function() {
        $ngConfirm({
            title: 'Atenção',
            content: 'Tem certeza que deseja sair do sistema?',
            scope: $scope,
            buttons: {
                not: {
                    text: 'Não',
                    btnClass: 'btn-danger'
                },
                yes: {
                    text: 'Sim',
                    btnClass: 'btn-primary',
                    action: function() {
                        $http.post('../api/acesso.php?logout')
                        .then(function() {
                            localStorage.removeItem('@token');
                            
                            // Limpa o histórico de navegação
                            if (window.history && window.history.pushState) {
                                window.history.pushState('', '', '../login/acesso.html');
                            }
    
                            window.location.href = '../login/acesso.html';
                        });
                    }
                }
            }
        });
    };
});

app.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/');

    let token = localStorage.getItem('@token');
    if(token == null){
        window.location.href = '../src/index.html#!/painel';
    }

 //==================================================================================================================================               
 //==================================================================================================================================               

 
 $stateProvider
 .state('produtos', {
     url: '/produtos',
     templateUrl: '../pages/produtos/grid.html',

    

     controller: function($scope, $http, $ngConfirm) {
         // Listar produtos
         $http.get('../api/list_products.php').then(function(response) {
             $scope.products = response.data;
         });

         function validarNumero(valor) {
            return !isNaN(parseFloat(valor)) && isFinite(valor) && Number(valor) >= 0;
        }
        
         $scope.clearMessage = function() {
            $scope.mensagem = { tipo: '', texto: '' };
         };

         // Função para adicionar e editar produtos
         $scope.send = function(action, product) {
            if (action === 'add') {
                // Inicialização do objeto para adicionar um novo produto
                $scope.item = {
                    nome: '',
                    preco_de_custo: '',
                    preco_de_venda: '',
                    quantidade_em_estoque: '',
                    unidade_de_medida: ''  // Inicializando unidade_de_medida como uma string vazia
                };
            } else {
                $scope.item = product ? angular.copy(product) : {};
            }

            // Limpar a mensagem antes de abrir o diálogo
            $scope.clearMessage();

            $ngConfirm({
                title: (action == 'add') ? 'Cadastrar Produto' : 'Atualizar Produto',
                contentUrl: '../pages/produtos/form.html',
                scope: $scope,
                typeAnimed: true,
                closeIcon: true,
                theme: 'dark',
                buttons: {
                    save: {
                        text: (action == 'add') ? 'Salvar' : 'Editar',
                        btnClass: 'btn-primary',
                        action: function(scope, button) {
                            // Verificar se unidade_de_medida foi definida corretamente
                            if (!$scope.item.unidade_de_medida || $scope.item.unidade_de_medida === '0') {
                                $scope.mensagem = { tipo: 'erro', texto: 'Por favor, selecione uma unidade de medida válida.' };
                                return false;
                            }

                            if (!validarNumero($scope.item.preco_de_custo) || 
                             !validarNumero($scope.item.preco_de_venda) || 
                             !validarNumero($scope.item.quantidade_em_estoque)) {
                             $scope.mensagem = { tipo: 'erro', texto: 'Por favor, insira valores numéricos e não negativos.' };
                             return false;
                             }    
                            // Verificar se os valores são maiores que zero
                            if ($scope.item.preco_de_custo < 0 || $scope.item.preco_de_venda < 0 || $scope.item.quantidade_em_estoque < 0) {
                                $scope.mensagem = { tipo: 'erro', texto: 'Os valores não podem ser menores que zero.' };
                                return false;
                            }

                            // Transforma o objeto em uma string codificada em x-www-form-urlencoded
                            const data = $.param($scope.item);
        
                            // Envia os dados usando o Content-Type correto
                            $http.post('../api/save_product.php', data, {
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                            }).then(function(response) {
                                if (response.data && response.data.status === 200) {
                                    if (action === 'add') {
                                        $scope.clearMessage();
                                        $scope.products.push($scope.item);
                                        // Mensagem de sucesso ao adicionar                                        
                                        $scope.mensagem = { tipo: 'sucesso', texto: 'Produto adicionado com sucesso!' };
                                    } else {
                                        // Mensagem de sucesso ao editar
                                        $scope.clearMessage();
                                        $scope.mensagem = { tipo: 'sucesso', texto: 'Produto alterado com sucesso!' };
                                    }
                                    // Recarrega os produtos após uma operação bem-sucedida
                                    $http.get('../api/list_products.php').then(function(response) {
                                        $scope.products = response.data;
                                    });
                            
                                    // Limpa as labels do form após o cadastro
                                    $scope.item = {
                                        nome: '',
                                        preco_de_custo: '',
                                        preco_de_venda: '',
                                        quantidade_em_estoque: '',
                                        unidade_de_medida: ''
                                    };
                            
                                } else {
                                    // Mensagem de erro
                                    $scope.clearMessage();
                                    $scope.mensagem = { tipo: 'erro', texto: response.data ? response.data.message : 'Erro desconhecido ao processar a operação.' };
                                }
                            }).catch(function(error) {
                                $scope.clearMessage();
                                // Mensagem de erro em caso de falha na requisição
                                $scope.mensagem = { tipo: 'erro', texto: 'Esse nome já existe!' };
                            });
                            return false;
                        }
                    },
                    close: {
                        text: 'Cancelar',
                        btnClass: 'btn-danger'
                    }
                }
            });
        };
    }
})

        


 //==================================================================================================================================               
 //==================================================================================================================================               
        
 $stateProvider
 .state('users', {
     url: '/users',
     templateUrl: '../pages/users/grid.html',
     controller: function ($scope, $http, $ngConfirm) {

        // LISTAR DADOS
        $http.get('../api/list_users.php?list')
            .then(function (response) {
                $scope.grid = response.data.map(user => {
                    user.ativo = Boolean(Number(user.ativo));
                    return user;
                });
            });
            

            $scope.toggleActive = function (index, user) {
                const active = !user.ativo; // Inverte o estado de ativo
                $http.post('../api/toggle_user.php?id=' + user.id + '&ativo=' + active)
                    .then(function (response) {
                        if (response.data.status === 200) {
                            $scope.grid[index].ativo = active; // Atualiza o estado no front-end
                            swal({
                                title: "Sucesso!",
                                text: 'Usuário ' + (active ? 'ativado' : 'desativado') + ' com sucesso!',
                                icon: "success",
                            });
                        }
                    });
            };
            

        // FUNÇÃO PARA ADICIONAR NOVO USUÁRIO
        $scope.addUser = function() {
            $scope.item = {}; // Objeto vazio para um novo usuário
        
            var ngConfirmInstance = $ngConfirm({
                title: 'Cadastrar Usuario',
                contentUrl: '../pages/users/formNew.html',
                scope: $scope,
                typeAnimed: true,
                closeIcon: true,
                theme: 'dark',
                buttons: {
                    yes: {
                        text: 'Salvar',
                        btnClass: 'btn-primary',
                        action: function(scope, button) {
                             // Validar se a nova senha e a confirmação são iguais
                             if ($scope.item.senha !== $scope.item.confirmaSenha) {
                                $('.msg').text('A nova senha e a confirmação de senha não coincidem.').addClass('alert alert-danger');
                                return false;
                            }

                            // Validar se a senha tem mais de 6 caracteres
                            if ($scope.item.senha && $scope.item.senha.length < 6) {
                                $('.msg').text('A senha deve ter mais de 6 caracteres.').addClass('alert alert-danger');
                                return false;
                            }
                            
                            sendData('add', $scope.item, function() {
                                ngConfirmInstance.close();
                            });
                            return false; // Impede que o ngConfirm feche automaticamente
                        }
                    }
                }
            });
        };

        $scope.editUser = function(user) {
            $scope.item = angular.copy(user);
        
            var ngConfirmInstance = $ngConfirm({
                title: 'Atualizar Usuario',
                contentUrl: '../pages/users/formEdit.html',
                scope: $scope,
                typeAnimed: true,
                closeIcon: true,
                theme: 'dark',
                buttons: {
                    yes: {
                        text: 'Editar',
                        btnClass: 'btn-primary',
                        action: function(scope, button) {
                            // Verificar se a senha atual está correta
                            $http.post('../api/verify_password.php', { id: user.id, senhaAtual: $scope.item.senhaAtual })
                                .then(function(response) {
                                    if (response.data.status === 200) {
                                        // Continuar com a lógica de atualização
                                        return true;
                                    } else {
                                        $('.msg').text('Senha atual incorreta').addClass('alert alert-danger');
                                        return false; // Não prossegue com a atualização
                                    }
                                })
                                .then(function(shouldUpdate) {
                                    if (shouldUpdate) {
                                        // Validar se a nova senha e a confirmação são iguais
                                        if ($scope.item.senha !== $scope.item.confirmaSenha) {
                                            $('.msg').text('A nova senha e a confirmação de senha não coincidem.').addClass('alert alert-danger');
                                            return false;
                                        }
        
                                        // Validar se a senha tem mais de 6 caracteres
                                        if ($scope.item.senha && $scope.item.senha.length < 6) {
                                            $('.msg').text('A senha deve ter mais de 6 caracteres.').addClass('alert alert-danger');
                                            return false;
                                        }
        
                                        // Enviar dados para editar usuário
                                        sendData('edit', $scope.item, function() {
                                            ngConfirmInstance.close();
                                        });
                                    }
                                })
                                .catch(function(error) {
                                    // Tratar erro da requisição
                                    $('.msg').text('Erro na requisição: ' + error).addClass('alert alert-danger');
                                });
        
                            return false; // Impede que o ngConfirm feche automaticamente
                        }
                    }
                }
            });
        };
        
        

        // FUNÇÃO PARA ENVIAR DADOS
        function sendData(action, data, closeCallback) {
            let url = '../api/save_users.php';
            if (action === 'edit') {
                url += '?id=' + data.id;
            }
        
            $.post(url, data, function(response) {
                $('.msg').text(response.msg).removeClass('alert-danger');
        
                if (response.status == 200) {
                    $('.msg').addClass('alert alert-success');
                    
                    // Recarregar dados do usuário após ação bem-sucedida
                    $http.get('../api/list_users.php?list')
                        .then(function (response) {
                            $scope.grid = response.data.map(user => {
                                user.ativo = Boolean(Number(user.ativo));
                                return user;
                            });
                        });
        
                    // Fecha o $ngConfirm após um breve atraso
                    setTimeout(function() {
                        closeCallback(); // Usa o callback para fechar o ngConfirm
                    }, 1000);
        
                } else {
                    $('.msg').addClass('alert alert-danger');
                    // Mantém o $ngConfirm aberto em caso de erro
                }
            }, "json");
        }
    }
});


 //==================================================================================================================================               
 //==================================================================================================================================               

 $stateProvider.state('cupom', {
    url: '/cupom',
    templateUrl: '../pages/cupom/grid.html',
    controller: 'CupomController'
});
}]);

app.controller('CupomController', function($scope, $http, $ngConfirm) {
    
    $scope.loadCupons = function() {
        $http.get('../api/cupons.php').then(function(response) {
            $scope.cupons = response.data.data.map(cupom => {
                cupom.ativo = Boolean(cupom.ativo);
                return cupom;
            });
        });
    }
    $scope.isCupomNameExists = function(nomeCupom) {
        return $scope.cupons.some(cupom => cupom.nome === nomeCupom);
    };

    $scope.loadCupons();

    $scope.clearMessage = function() {
        $scope.mensagem = { tipo: '', texto: '' };
    };

    
    

    $scope.addCupom = function() {
        $scope.clearMessage();
        if ($scope.isCupomNameExists($scope.item.nome)) {
            $scope.mensagem = { tipo: 'erro', texto: 'Cupom com este nome já existe.' };
            return;
        }
        if ($scope.item.desconto < 0 || $scope.item.desconto > 100) {
            $scope.mensagem = { tipo: 'erro', texto: 'Desconto deve estar entre 0% e 100%.' };
            return;
        }

        const data = {
            nome: $scope.item.nome,
            desconto: $scope.item.desconto
        };

        $http.post('../api/cupons.php', data).then(
            function(response) {
                if (response.data.status === 200) {
                    $scope.mensagem = { tipo: 'sucesso', texto: 'Cupom cadastrado com sucesso!' };
                } else {
                    $scope.mensagem = { tipo: 'erro', texto: response.data.message };
                }
                $scope.loadCupons();
            }, function(errorResponse) {
                $scope.mensagem = { tipo: 'erro', texto: 'Erro na requisição: ' + errorResponse.statusText };
                $scope.loadCupons();
            }
        
        );
            
    };

    $scope.showAddCupomModal = function() {
        $scope.clearMessage();
        $scope.item = { nome: '', desconto: '' };
    
        $ngConfirm({
            title: 'Cadastrar Novo Cupom',
            contentUrl: '../pages/cupom/form.html',
            scope: $scope,
            typeAnimated: true,
            closeIcon: true,
            theme: 'dark',
            buttons: {
                save: {
                    text: 'Salvar',
                    btnClass: 'btn-primary',
                    action: function(scope, button) {
                        if ($scope.item.desconto < 0 || $scope.item.desconto > 100) {
                            $scope.mensagem = { tipo: 'erro', texto: 'Desconto deve estar entre 0% e 100%.' };
                            return false;
                        }
                        if ($scope.isCupomNameExists($scope.item.nome)) {
                            $scope.mensagem = { tipo: 'erro', texto: 'Cupom com este nome já existe.' };
                            return false;
                        }
                        
                        // Aqui você pode chamar a função addCupom para adicionar o cupom
                        $scope.addCupom();
                        return false; // Mantém o modal aberto até a promessa ser resolvida
                    }
                },
                close: {
                    text: 'Cancelar',
                    btnClass: 'btn-danger'
                }
            }
        });
    };

    $scope.desativarCupom = function(cupom) {
        const data = { nome: cupom.nome, action: 'desativar' };
        $http.put('../api/cupons.php', data).then(function(response) {
            if (response.data.status === 200) {
                cupom.ativo = false;
                swal("Desativado!", "Cupom desativado com sucesso.", "success");
            } else {
                swal("Erro!", response.data.message, "error");
            }
        });
    };
    
    $scope.ativarCupom = function(cupom) {
        const data = { nome: cupom.nome, action: 'ativar' };
        $http.put('../api/cupons.php', data).then(function(response) {
            if (response.data.status === 200) {
                cupom.ativo = true;
                swal("Ativado!", "Cupom ativado com sucesso.", "success");
            } else {
                swal("Erro!", response.data.message, "error");
            }
        });
    };
    

    $scope.updateCupom = function() {
        $scope.clearMessage();
        const existingCupom = $scope.cupons.find(cupom => cupom.nome === $scope.item.nome && cupom.id !== $scope.item.id);
        
        if (existingCupom) {
            $scope.mensagem = { tipo: 'erro', texto: 'Outro cupom com este nome já existe.' };
            return;
        }
    
        if ($scope.item.desconto < 0 || $scope.item.desconto > 100) {
            $scope.mensagem = { tipo: 'erro', texto: 'Desconto deve estar entre 0% e 100%.' };
            return;
        }
    
        const data = {
            id: $scope.item.id,
            nome: $scope.item.nome,
            desconto: $scope.item.desconto
        };
    
        $http.put('../api/cupons.php', data).then(function(response) {
            if (response.data.status === 200) {
                $scope.mensagem = { tipo: 'sucesso', texto: 'Cupom atualizado com sucesso!' };
            } else {
                $scope.mensagem = { tipo: 'erro', texto: response.data.message };
            }
            $scope.loadCupons();
        }, function(errorResponse) {
            $scope.mensagem = { tipo: 'erro', texto: 'Erro na requisição: ' + errorResponse.statusText };
            $scope.loadCupons();
        });
    };  

    $scope.showEditCupomModal = function(cupom) {
        $scope.item = angular.copy(cupom); // Aqui garantimos que $scope.item tem as propriedades necessárias
        $scope.clearMessage();
    
        $ngConfirm({
            title: 'Editar Cupom',
            contentUrl: '../pages/cupom/form.html',
            scope: $scope,
            typeAnimated: true,
            closeIcon: true,
            theme: 'dark',
            buttons: {
                update: {
                    text: 'Atualizar',
                    btnClass: 'btn-primary',
                    action: function(scope, button) {
                        if ($scope.item.desconto < 0 || $scope.item.desconto > 100) {
                            $scope.mensagem = { tipo: 'erro', texto: 'Desconto deve estar entre 0% e 100%.' };
                            return false;
                        }
    
                        $scope.updateCupom();
                        return false; // Mantém o modal aberto até a promessa ser resolvida
                    }
                },
                close: {
                    text: 'Cancelar',
                    btnClass: 'btn-danger'
                        }
                    }
                });
            };

        }); 

       
//==================================================================================================================================               
 //==================================================================================================================================          
             


 app.config(['$stateProvider', function($stateProvider) {

    $stateProvider.state('venda', {
        url: '/venda',
        templateUrl: '../pages/venda/grid.html',
        controller: 'VendaController'
    });

}]);

app.service('VendaService', ['$http', function($http) {
    this.realizarVenda = function(data) {
        return $http.post('../api/api_venda.php', data);
    };
}]);

app.controller('VendaController', ['$scope', 'VendaService', '$http', function($scope, VendaService, $http) {
    $scope.produtos = [];
    $scope.produtosVenda = [];
    $scope.produtoSelecionado = null;
    $scope.quantidade = null;
    $scope.usuarioId = null;  // Inicializar usuarioId com null


    // Carregar produtos do servidor quando o controlador for iniciado
    $http.get('../api/list_products.php').then(function(response) {
        $scope.produtos = response.data;
    }).catch(function(error) {
        swal("Erro ao carregar produtos!", error.message, "error");
    });

    $scope.adicionarProduto = function() {
        if ($scope.produtoSelecionado) {
            if ($scope.quantidade <= 0) {
                swal("Erro!", "A quantidade deve ser maior que zero.", "error");
                return;
            }
    
            if ($scope.produtoSelecionado.preco_de_venda <= 0) {
                swal("Erro!", "O preço de venda deve ser maior que zero.", "error");
                return;
            }
    
            if ($scope.produtoSelecionado.quantidade_em_estoque <= 0) {
                swal("Erro!", "O produto está fora de estoque.", "error");
                return;
            }
    
            let produtoVenda = {
                id: $scope.produtoSelecionado.id,
                nome: $scope.produtoSelecionado.nome,
                quantidade: $scope.quantidade,
                preco_de_venda: $scope.produtoSelecionado.preco_de_venda,
                unidade_de_medida: $scope.produtoSelecionado.unidade_de_medida
            };
            $scope.produtosVenda.push(produtoVenda);
        }
    };

           $scope.aplicarCupom = function() {
    const nomeCupom = $scope.nomeCupom;
    if (!nomeCupom) {
        swal("Erro!", "Por favor, insira o nome do cupom.", "error");
        return;
    }

    $http.post('../api/aplicar_cupom.php', { nome_cupom: nomeCupom }).then(response => {
        if (response.data.status === 200) {
            $scope.cupomAplicado = response.data.cupom;
            $scope.desconto = $scope.cupomAplicado.desconto;

            $scope.valorDescontado = $scope.calcularTotal() * ($scope.desconto / 100);
            $scope.valorTotalComDesconto = $scope.calcularTotal() - $scope.valorDescontado;

            swal("Sucesso!", "Cupom aplicado com sucesso!", "success");
        } else {
            swal("Erro!", response.data.message, "error");
        }
    }).catch(error => {
        swal("Erro ao aplicar cupom!", error.message, "error");
    });
};
    
    $scope.calcularTotal = function() {
        let total = 0;
        for (let produto of $scope.produtosVenda) {
            total += produto.preco_de_venda * produto.quantidade;
        }
        return total;
    };

    $scope.removerProduto = function(index) {
        $scope.produtosVenda.splice(index, 1);
    };
    
    $scope.getValorTotal = function() {
        let total = 0;
        $scope.produtosVenda.forEach(produto => {
            total += produto.preco_de_venda * produto.quantidade;
        });
        return total;
    };
    

    $scope.resetForm = function() {
        $scope.produtosVenda = [];
        $scope.produtoSelecionado = null;
        $scope.quantidade = null;
        $scope.nomeCupom = null;
        $scope.desconto = null;
        $scope.valorDescontado = null;
        $scope.valorTotalComDesconto = null;
        $scope.usuarioId= null;
        // Adicione outras propriedades conforme necessário
    };
    
    $scope.finalizarVenda = function() {
        let data = {
            produtosVenda: $scope.produtosVenda,
            desconto: $scope.desconto,
            usuarioId: $scope.usuarioId,
            cupomAplicado: $scope.cupomAplicado ? $scope.cupomAplicado.id : null
        };
    
        VendaService.realizarVenda(data).then(function(response) {
            if (response.data.status === 'success') {
                // Atualize o estoque dos produtos na lista local após a venda
                $scope.produtosVenda.forEach(function(produtoVenda) {
                    const produto = $scope.produtos.find(p => p.id === produtoVenda.id);
                    if (produto) {
                        produto.quantidade_em_estoque -= produtoVenda.quantidade;
                    }
                });
    
                swal("Sucesso!", response.data.message, "success");
                $scope.resetForm();
            } else {
                swal("Erro!", "Erro: " + response.data.message, "error");
            }
        }).catch(function(error) {
            swal("Erro na chamada!", error.message, "error");
        });
    };
}]);


//==================================================================================================================================               
 //==================================================================================================================================               
 app.config(['$stateProvider', function($stateProvider) {
    $stateProvider.state('relatorioVenda', {
        url: '/relatorioVenda',
        templateUrl: '../pages/relatorioVenda/grid.html',
        controller: 'RelatorioController'
    });
}]);

// Definição do filtro para a moeda
app.filter('customCurrency', function() { 
    return function(input) {
        return 'R$ ' + parseFloat(input).toFixed(2);
    };
});

// Controlador para o relatório
app.controller('RelatorioController', ['$scope', '$http', '$element', '$templateRequest', '$compile', function($scope, $http, $element, $templateRequest, $compile) {
    
    // Função para formatar a data para o padrão esperado pelo backend
    function formatarData(data) {
        if (data instanceof Date) {
            return data.toISOString().split('T')[0];
        } else if (typeof data === 'string' && data.indexOf('/') > -1) {
            var partesData = data.split('/');
            if (partesData.length === 3) {
                return partesData[2] + '-' + partesData[1] + '-' + partesData[0];
            }
        }
        return data; // Retorna a data sem alterações se não estiver nos formatos esperados
    }
    function dividirEmGrupos(dados, tamanhoDoGrupo) {
        var grupos = [];
        for (var i = 0; i < dados.length; i += tamanhoDoGrupo) {
            grupos.push(dados.slice(i, i + tamanhoDoGrupo));
        }
        return grupos;
    }

    // Supondo que $scope.rows já esteja preenchido com os dados
    


    $scope.$watch('filtro.dataVenda', function (newValue) {
        if (newValue) {
          // Converte a string de data para um objeto Date
          var data = new Date(newValue);
      
          // Certifique-se de que a conversão foi bem-sucedida
          if (!isNaN(data.getTime())) {
            // Configura a hora para meia-noite
            data.setHours(0, 0, 0, 0);
            // Atualiza o modelo com a nova data
            $scope.filtro.dataVenda = data;
          } else {
            // Manipule o erro de conversão aqui, se necessário
            console.error('Data fornecida é inválida:', newValue);
          }
        }
      });

      

    $scope.loadDados = function(filtro = {}) {
        console.log('Data de venda antes do request:', filtro.dataVenda);
        // Formata a data de venda se ela existir
        if (filtro.dataVenda) {
            filtro.dataVenda = formatarData(filtro.dataVenda);
        }

        // Passa o objeto filtro como parâmetros de URL
        $http.get('../api/relatorio_venda.php', { params: filtro }).then(function(response) {
            $scope.rows = response.data;
            $scope.gruposDeRows = dividirEmGrupos($scope.rows, 15);
            // Calculando o valor total de cada venda
            $scope.rows.forEach(row => {
                row.valor_total_venda = row.preco_de_venda - row.desconto_reais;
            });
            var tableElement = $element[0].querySelector('.table');
            if (tableElement) {
                tableElement.style.width = '200%';
                tableElement.style.marginBottom = '1rem';
                tableElement.style.color = '#858796';
            }

        }).catch(function(error) {
            console.error('Erro ao carregar os dados:', error);
        });
    };

    $scope.loadDados(); // chamada à função inicial

    $scope.gerarPDF = function() {
        $templateRequest('../pages/relatorioVenda/gridPDF.html').then(function(template) {
            // Compilando o template
            $scope.gruposDeRows = dividirEmGrupos($scope.rows, 15);
            var compiled = $compile(template)($scope);
    
            var opt = {
                margin: 1,
                filename: 'relatorioVenda.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            html2pdf().from(compiled[0]).set(opt).save();
            $scope.gruposDeRows = dividirEmGrupos($scope.rows, 15);

        });
    };

    
    $scope.gerarPDFLista = function() {

        $scope.gruposDeRows = dividirEmGrupos($scope.rows, 3);
        $templateRequest('../pages/relatorioVenda/gridPDF2.html').then(function(template) {
           
            // Compilando o template
            var compiled = $compile(template)($scope);
            
            var opt = {
                margin: 1,
                filename: 'relatorioVendaLista.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
    
            html2pdf().from(compiled[0]).set(opt).save();
           
        });
    };
    
}]);


//====================================================================
//===================================================================


app.config(['$stateProvider', function($stateProvider) {
    $stateProvider.state('relatorioEstoque', {
        url: '/relatorioEstoque',
        templateUrl: '../pages/relatorioProduto/grid.html',
        controller: 'relatorioControllerEstoque'
    });
}]);
app.controller('relatorioControllerEstoque', ['$scope', '$http', function($scope, $http) {
    $scope.rows = [];

    // Buscar dados do relatório
    $http.get('../api/relatorioProduto.php').then(function(response) {
        $scope.rows = response.data;
    });
}]);


//====================================================================
//===================================================================
app.config(['$stateProvider', function($stateProvider) {
    $stateProvider.state('relatorioLucro', {
        url: '/relatorioLucro',
        templateUrl: '../pages/relatorioLucro/grid.html',
        controller: 'relatorioControllerLucro'
    });
}]);

app.controller('relatorioControllerLucro', ['$scope', '$http', '$element', '$compile', '$templateRequest',
  function($scope, $http, $element, $compile, $templateRequest) {
    $scope.ano = new Date().getFullYear(); // Ano atual como padrão
    $scope.mes = null;
    $scope.dia = null;
    $scope.rows = [];
    $scope.lucroTotal = 0; // Inicialize com 0 aqui

    $scope.buscarLucro = function() {
        let params = {};
        if ($scope.ano) params.ano = $scope.ano;
        if ($scope.mes) params.mes = $scope.mes;
        if ($scope.dia) params.dia = $scope.dia;

        $http.get('../api/relatorioLucro.php', { params: params }).then(function(response) {
            $scope.rows = response.data.data;
            if (response.data.lucroTotal !== null) {
                $scope.lucroTotal = response.data.lucroTotal;
            } else {
                $scope.lucroTotal = 0; // Se o lucro total vier como null, defina como 0
            }
        }); // Esta chave fecha a função buscarLucro
    }; // Esta chave fecha a definição de buscarLucro

    $scope.gerarPDF = function() {
        $templateRequest('../pages/relatorioLucro/gridPDF.html').then(function(template) {
            // Compilando o template com o escopo atual
            var compiled = $compile(template)($scope);

            // Definindo as opções para o html2pdf
            var opt = {
                margin: 1,
                filename: 'relatorioLucro.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            // Utilizando o html2pdf para criar o PDF a partir do template compilado
            html2pdf().from(compiled[0]).set(opt).save();
        });
    }; 
}]); 

//====================================================================
//===================================================================

app.config(['$stateProvider', function($stateProvider) {
    $stateProvider.state('painel', {
        url: '/painel',
        templateUrl: '../pages/painel/grid.html',
        controller: 'PainelController'
    });
}]);

app.controller('PainelController', ['$scope', function($scope) {
    // Lógica do controlador
}]);

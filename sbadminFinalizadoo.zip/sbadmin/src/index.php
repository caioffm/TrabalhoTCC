<?php
include '../api/private/connect.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user']) || !isset($_SESSION['user']['token'])) {
    // Usuário não está logado, redirecione para a página de login.
    header('Location: ../login/acesso.html');
    exit;
}

?>

<?php
require(__DIR__ . '/../vendor/autoload.php');
include 'private/connect.php';


use Firebase\JWT\JWT;

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $mysqli->prepare("SELECT id, nome, senha, tipo, ativo FROM usuarios WHERE username = ? AND ativo = TRUE");
    $stmt->bind_param("s", $username);

    if ($stmt->execute()) {
        $stmt->bind_result($id, $nome, $hashed_password, $tipo, $ativo);

        if ($stmt->fetch()) {
            if ($ativo) {
                if (password_verify($password, $hashed_password)) {
                    // Guardar nome na sessão
                $_SESSION['nome'] = $nome;
                    // Gerar JWT Token
                    $key = "caiocaio1";
                    $payload = array(
                        "id" => $id,
                        "username" => $username,
                        "tipo" => $tipo,  // adicionando o tipo de usuário aqui
                        "iat" => time(),
                        "exp" => time() + (60*60) // expira em 1 hora
                    );
                    
                    

                    $jwt = JWT::encode($payload, $key, 'HS256');

                    $_SESSION['user'] = array(
                        'id' => $id,
                        'username' => $username,
                        'tipo' => $tipo,  // adicionando o tipo de usuário aqui
                        'token' => $jwt // Guardar o JWT na sessão
                    );

                    $response = array('msg' => 'Login efetuado com sucesso', 'status' => 200, 'token' => $jwt);
                } else {
                    $response = array('msg' => 'Usuário ou senha inválidos', 'status' => 403);
                }
            } else {
                $response = array('msg' => 'Conta desativada. Por favor, entre em contato com o administrador', 'status' => 403);
            }
        } else {
            $response = array('msg' => 'Usuário ou senha inválidos', 'status' => 403);
        }
        $stmt->close();
    } else {
        $response = array('msg' => 'Erro ao acessar o banco de dados', 'status' => 500);
    }

    echo json_encode($response);
}

if (isset($_GET['logout'])) {
    // Limpa a sessão
    $_SESSION = array();

    // Destruir a sessão
    session_destroy();

    // Se você estiver usando cookies para a sessão, remova o cookie da sessão.
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Define a resposta como sucesso
    $response['status'] = 'success';
    echo json_encode($response);
    exit;
}
?>

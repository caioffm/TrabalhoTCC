    <?php
    header("Content-Type: application/json");
    header("Access-Control-Allow-Origin: *");

    include "private/connect.php";


    $response = array();

    // Checando método POST
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Verificando se as chaves estão definidas antes de usá-las
        $id = isset($_POST['id']) ? $_POST['id'] : null;
        $nome = isset($_POST['nome']) ? $_POST['nome'] : null;
        $preco_de_custo = isset($_POST['preco_de_custo']) ? $_POST['preco_de_custo'] : null;
        $preco_de_venda = isset($_POST['preco_de_venda']) ? $_POST['preco_de_venda'] : null;
        $quantidade_em_estoque = isset($_POST['quantidade_em_estoque']) ? $_POST['quantidade_em_estoque'] : null;
        $unidade_de_medida = isset($_POST['unidade_de_medida']) ? $_POST['unidade_de_medida'] : null;

        if ($preco_de_venda <= $preco_de_custo) {
            $response['status'] = 400;
            $response['message'] = "O preço de venda deve ser maior que o preço de custo.";
            echo json_encode($response);
            exit;
        }

        // Se algum desses valores for null, retorna um erro
        if (!$nome || !$preco_de_custo || !$preco_de_venda || !$quantidade_em_estoque || !$unidade_de_medida) {
            $response['status'] = 400;
            $response['message'] = "Dados de produto incompletos.";
            echo json_encode($response);
            exit;
        }

        if ($id) {
            $stmt = $mysqli->prepare("UPDATE produtos SET nome=?, preco_de_custo=?, preco_de_venda=?, quantidade_em_estoque=?, unidade_de_medida=? WHERE id=?");
            $stmt->bind_param("sssssi", $nome, $preco_de_custo, $preco_de_venda, $quantidade_em_estoque, $unidade_de_medida, $id);
        } else {
            $stmt = $mysqli->prepare("INSERT INTO produtos (nome, preco_de_custo, preco_de_venda, quantidade_em_estoque, unidade_de_medida, id) VALUES (?, ?, ?, ?, ? ,?)");
            $stmt->bind_param("sssssi", $nome, $preco_de_custo, $preco_de_venda, $quantidade_em_estoque, $unidade_de_medida, $id);
            
        }

        if ($stmt->execute()) {
            $response['status'] = 200;
            $response['message'] = $id ? "Produto atualizado com sucesso." : "Produto inserido com sucesso.";
        } else {
            $response['status'] = 500;
            $response['message'] = "Erro ao salvar produto: " . $stmt->error;
        }
    } else {
        $response['status'] = 405;
        $response['message'] = "Método não permitido";
    }

    header('Content-Type: application/json');
    echo json_encode($response);

    $mysqli->close();
    ?>

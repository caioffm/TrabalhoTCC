<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php"; // Inclua o arquivo de conexão

$data = json_decode(file_get_contents("php://input"));

$id = $data->id;
$senhaAtual = $data->senhaAtual;

$stmt = $mysqli->prepare("SELECT senha FROM usuarios WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    if (password_verify($senhaAtual, $row['senha'])) {
        echo json_encode(array('status' => 200, 'msg' => 'Senha verificada com sucesso.'));
    } else {
        echo json_encode(array('status' => 500, 'msg' => 'Senha atual incorreta.'));
    }
} else {
    echo json_encode(array('status' => 500, 'msg' => 'Usuário não encontrado.'));
}

$stmt->close();
$mysqli->close();
?>

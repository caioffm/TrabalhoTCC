<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php"; // Inclua o arquivo de conexão

error_log("Received POST data: " . print_r($_POST, true)); // Isso irá registrar os dados recebidos no arquivo de log

try {
    // Receba os dados do usuário via POST
    $nome = $_POST['nome'];
    $username = $_POST['username'];
    $senha = isset($_POST['senha']) ? $_POST['senha'] : null; // Verifica se a senha foi fornecida
    $tipo = $_POST['tipo'];

    // Criptografa a senha, se fornecida
    if ($senha) {
        $senha = password_hash($senha, PASSWORD_DEFAULT);
    }

    // Verifique se é uma adição de novo usuário ou atualização de usuário existente
    if (isset($_GET['id'])) {
        if ($senha) {
            $stmt = $mysqli->prepare("UPDATE usuarios SET nome=?, username=?, senha=?, tipo=? WHERE id=?");
            $stmt->bind_param("ssssi", $nome, $username, $senha, $tipo, $_GET['id']);
        } else {
            $stmt = $mysqli->prepare("UPDATE usuarios SET nome=?, username=?, tipo=? WHERE id=?");
            $stmt->bind_param("sssi", $nome, $username, $tipo, $_GET['id']);
        }
    } else {
        $stmt = $mysqli->prepare("INSERT INTO usuarios (nome, username, senha, tipo, ativo) VALUES (?, ?, ?, ?, 1)");
        $stmt->bind_param("ssss", $nome, $username, $senha, $tipo);
    }
    
    if ($stmt->execute()) {
        $response = array('status' => 200, 'msg' => 'Usuário salvo com sucesso.');
    } else {
        $response = array('status' => 500, 'msg' => 'Erro ao salvar o usuário: ' . $stmt->error);
    }

    echo json_encode($response);
} catch (Exception $e) {
    // Registre a exceção para depuração
    echo json_encode(array('status' => 500, 'msg' => 'Erro desconhecido: ' . $e->getMessage()));
}

mysqli_close($mysqli);
?>

<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php"; // Inclua o arquivo de conexão

// Query para selecionar todos os usuários
$query = "SELECT * FROM usuarios";
$result = mysqli_query($mysqli, $query);

if (!$result) {
    die('Erro na consulta: ' . mysqli_error($mysqli));
}

$users = array();
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}

echo json_encode($users);

mysqli_close($mysqli);
?>

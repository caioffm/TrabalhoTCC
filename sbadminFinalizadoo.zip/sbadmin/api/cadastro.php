<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php"; // Incluindo o arquivo de conexão


$response = array('success' => false, 'message' => 'Erro no cadastro.');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $usuario = $_POST['usuario'];
    $senha = password_hash($_POST['password'], PASSWORD_DEFAULT); // Vamos usar uma senha criptografada
    $tipo = $_POST['tipo'];
    $ativo = 1; // Valor padrão para ativo

    // Verificando se as senhas coincidem
    if ($_POST['password'] !== $_POST['password2']) {
        $response['message'] = "Senhas não coincidem!";
        echo json_encode($response);
        exit;
    }

    $stmt = $mysqli->prepare("INSERT INTO usuarios (nome, username, senha, tipo, ativo) VALUES (?, ?, ?, ?, ?)");
    
    if ($stmt) {
        $stmt->bind_param("sssss", $nome, $usuario, $senha, $tipo, $ativo);
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Cadastro realizado com sucesso!";
        } else {
            $response['message'] = "Erro: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $response['message'] = "Erro: " . $mysqli->error;
    }

    echo json_encode($response);
}
?>

<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php";


$query = "SELECT * FROM produtos";
$result = mysqli_query($mysqli, $query);

// Tratamento de erros
if (!$result) {
    die('Erro na consulta: ' . mysqli_error($mysqli));
}

$products = array();
while ($row = mysqli_fetch_assoc($result)) {
    $products[] = $row;
}

echo json_encode($products);

// Fechando a conexão
mysqli_close($mysqli);
?>

<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php"; // Inclua o arquivo de conexão

// Query para selecionar todos os produtos
$query = "SELECT * FROM produtos";
$result = mysqli_query($mysqli, $query);

if (!$result) {
    die('Erro na consulta: ' . mysqli_error($mysqli));
}

$produtos = array();
while ($row = mysqli_fetch_assoc($result)) {
    $produtos[] = $row;
}

echo json_encode($produtos);

mysqli_close($mysqli);
?>

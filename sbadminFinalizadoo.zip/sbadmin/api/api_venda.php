<?php
// Incluindo a função de verificação do token
include 'private/verificar_token.php';

// Iniciando sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Cabeçalhos
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include "private/connect.php";


// Verificar se o usuário está logado via sessão ou token
$usuario_id = null;
if (isset($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $usuario_id = $_SESSION['user']['id'];
} elseif (isset($_SESSION['user']['token'])) {
    $token = $_SESSION['user']['token'];
    $result = verificarToken($token);
    if (isset($result['status']) && $result['status'] === 401) {
        $response["status"] = "error";
        $response["message"] = $result['msg'];
        echo json_encode($response);
        exit();
    } else {
        $usuario_id = $result['id'];
    }
}

if ($usuario_id === null) {
    $response["status"] = "error";
    $response["message"] = "Usuário não está logado.";
    echo json_encode($response);
    exit();
}

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

$produtos_venda = $request->produtosVenda;
$cupom_aplicado = isset($request->cupomAplicado) ? $request->cupomAplicado : null;

// Verifique se há produtos na venda
if (empty($produtos_venda)) {
    $response["status"] = "error";
    $response["message"] = "Nenhum produto foi selecionado para a venda.";
    echo json_encode($response);
    exit();
}

$errors = [];
$total_venda = 0;

// Iniciar transação
$mysqli->begin_transaction();

try {
    foreach ($produtos_venda as $produto) {
        $stmt = $mysqli->prepare("SELECT quantidade_em_estoque FROM produtos WHERE id = ?");
        $stmt->bind_param("i", $produto->id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $quantidade_atual = $row['quantidade_em_estoque'];

        if ($produto->quantidade > $quantidade_atual) {
            $errors[] = "A quantidade vendida do produto '{$produto->nome}' excede o estoque disponível.";
            continue;
        }

        $total_venda += $produto->preco_de_venda * $produto->quantidade;

        $nova_quantidade = $quantidade_atual - $produto->quantidade;

        if ($nova_quantidade < 0) {
            $errors[] = "Erro ao calcular o estoque para o produto '{$produto->nome}'.";
            continue;
        }

        $update_stmt = $mysqli->prepare("UPDATE produtos SET quantidade_em_estoque = ? WHERE id = ?");
        $update_stmt->bind_param("ii", $nova_quantidade, $produto->id);

        if (!$update_stmt->execute()) {
            throw new Exception("Erro ao atualizar o estoque do produto '{$produto->nome}'.");
        }
    }

    // Consultar as informações do cupom, mesmo se nenhum cupom for aplicado
    $desconto_cupom = 0; // Defina um valor padrão para o desconto do cupom

    if ($cupom_aplicado !== null) {
        $stmt = $mysqli->prepare("SELECT desconto FROM cupons WHERE id = ?");
        $stmt->bind_param("i", $cupom_aplicado);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            $desconto_cupom = $row['desconto'];
        }
    }

    $total_venda = $total_venda * (1 - ($desconto_cupom / 100));

    if (count($errors) === 0) {
        $venda_stmt = $mysqli->prepare("INSERT INTO vendas (desconto, valor_total, cupom_id, usuario_id) VALUES (?, ?, ?, ?)");
        $venda_stmt->bind_param("diii", $desconto_cupom, $total_venda, $cupom_aplicado, $usuario_id);

        if (!$venda_stmt->execute()) {
            throw new Exception("Erro ao inserir venda.");
        }

        $venda_id = $mysqli->insert_id;

        foreach ($produtos_venda as $produto) {
            $detalhe_venda_stmt = $mysqli->prepare("INSERT INTO detalhes_vendas (venda_id, produto_id, quantidade, preco_de_venda, unidade_de_medida) VALUES (?, ?, ?, ?, ?)");
            $detalhe_venda_stmt->bind_param("iiids", $venda_id, $produto->id, $produto->quantidade, $produto->preco_de_venda, $produto->unidade_de_medida);

            if (!$detalhe_venda_stmt->execute()) {
                throw new Exception("Erro ao inserir detalhes da venda.");
            }
        }

        $response["status"] = "success";
        $response["message"] = "Venda realizada com sucesso!";
        $mysqli->commit(); // Confirma a transação
    } else {
        $mysqli->rollback(); // Reverte a transação
        $response["status"] = "error";
        $response["message"] = "Erros encontrados ao finalizar a venda:";
        $response["errors"] = $errors;
    }

} catch (Exception $e) {
    $mysqli->rollback(); // Em caso de erro, reverta a transação
    $response["status"] = "error";
    $response["message"] = $e->getMessage();
}

echo json_encode($response);
?>

<?php
header('Content-Type: application/json');

// Inicializando a sessão, se ela ainda não foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificando se o tipo de usuário está definido na sessão
if (isset($_SESSION['user']) && isset($_SESSION['user']['tipo'])) {
    echo json_encode(['status' => 200, 'tipo' => $_SESSION['user']['tipo']]);
} else {
    echo json_encode(['status' => 403, 'msg' => 'Tipo de usuário não identificado']);
}
?>

<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php";

$response = array();

// Função para verificar se uma string está em branco
function isBlank($str) {
    return empty(trim($str));
}

// Obter os cupons (GET)
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $cupons = [];
    $query = "SELECT id, nome, desconto, ativo FROM cupons";
    
    if ($result = $mysqli->query($query)) {
        while ($row = $result->fetch_assoc()) {
            $row['desconto'] = floatval($row['desconto']);
            $row['ativo'] = $row['ativo'] == 1;
            $cupons[] = $row;
        }
        $response['status'] = 200;
        $response['data'] = $cupons;
    } else {
        $response['status'] = 500;
        $response['message'] = "Erro ao buscar cupons: " . $mysqli->error;
    }
}

// Inserir um novo cupom (POST)
elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $nome = $data['nome'] ?? null;
    $desconto = $data['desconto'] ?? null;
    
    if (isBlank($nome) || isBlank($desconto) || !is_numeric($desconto)) {
        $response['status'] = 400;
        $response['message'] = "Dados do cupom incompletos ou inválidos.";
    } elseif ($desconto > 100 || $desconto < 0) {
        $response['status'] = 400;
        $response['message'] = "O valor do desconto é inválido. Ele deve estar entre 0% e 100%.";
    } else {
        $checkStmt = $mysqli->prepare("SELECT id FROM cupons WHERE nome = ?");
        $checkStmt->bind_param("s", $nome);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $response['status'] = 400;
            $response['message'] = "Nome do cupom já existe.";
        } else {
            $stmt = $mysqli->prepare("INSERT INTO cupons (nome, desconto, ativo) VALUES (?, ?, TRUE)");
            $stmt->bind_param("ss", $nome, $desconto);
            
            if ($stmt->execute()) {
                $response['status'] = 200;
                $response['message'] = "Cupom inserido com sucesso.";
            } else {
                $response['status'] = 500;
                $response['message'] = "Erro ao inserir cupom: " . $mysqli->error;
            }
        }
        $checkStmt->close();
    }
}

// Atualizar um cupom (PUT)
elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['id']) && isset($data['nome']) && isset($data['desconto'])) {
        $nome = $data['nome'];
        $desconto = $data['desconto'];
        $id = $data['id'];

        if (isBlank($nome) || isBlank($desconto) || !is_numeric($desconto)) {
            $response['status'] = 400;
            $response['message'] = "Dados do cupom incompletos ou inválidos.";
        } elseif ($desconto > 100 || $desconto < 0) {
            $response['status'] = 400;
            $response['message'] = "O valor do desconto é inválido. Ele deve estar entre 0% e 100%.";
        } else {
            $checkStmt = $mysqli->prepare("SELECT id FROM cupons WHERE nome = ? AND id != ?");
            $checkStmt->bind_param("si", $nome, $id);
            $checkStmt->execute();
            $checkStmt->store_result();

            if ($checkStmt->num_rows > 0) {
                $response['status'] = 400;
                $response['message'] = "Outro cupom com este nome já existe.";
            } else {
                $stmt = $mysqli->prepare("UPDATE cupons SET nome = ?, desconto = ? WHERE id = ?");
                $stmt->bind_param("sii", $nome, $desconto, $id);

                if ($stmt->execute()) {
                    $response['status'] = 200;
                    $response['message'] = "Cupom atualizado com sucesso.";
                } else {
                    $response['status'] = 500;
                    $response['message'] = "Erro ao atualizar cupom: " . $stmt->error;
                }
                $stmt->close();
            }
            $checkStmt->close();
        }
    }
    // Tratamento para ativação/desativação
    elseif (isset($data['nome']) && isset($data['action'])) {
        $nome = $data['nome'];
        $action = $data['action'];

        if ($action == 'ativar') {
            $ativo = TRUE;
        } elseif ($action == 'desativar') {
            $ativo = FALSE;
        } else {
            $response['status'] = 400;
            $response['message'] = 'Ação inválida.';
        }

        $stmt = $mysqli->prepare("UPDATE cupons SET ativo = ? WHERE nome = ?");
        $stmt->bind_param("is", $ativo, $nome);

        if ($stmt->execute()) {
            $response['status'] = 200;
            $response['message'] = "Cupom " . ($ativo ? 'ativado' : 'desativado') . " com sucesso.";
        } else {
            $response['status'] = 500;
            $response['message'] = "Erro ao alterar status do cupom: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $response['status'] = 400;
        $response['message'] = 'Dados incompletos para atualização.';
    }
}

header('Content-Type: application/json');
echo json_encode($response);

$mysqli->close();
?>

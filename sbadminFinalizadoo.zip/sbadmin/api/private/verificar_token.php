<?php
require(__DIR__ . '/../../vendor/autoload.php');
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;
use Firebase\JWT\SignatureInvalidException;

function verificarToken($token) {
    $key = "caiocaio1";  // a mesma chave secreta usada para gerar o token
    try {
        $decoded = JWT::decode($token, $key, array('HS256'));
        return (array) $decoded;
    } catch (ExpiredException $e) {
        return array('status' => 401, 'msg' => 'Token expirado.');
    } catch (SignatureInvalidException $e) {
        return array('status' => 401, 'msg' => 'Token inválido.');
    } catch (Exception $e) {
        return array('status' => 500, 'msg' => 'Erro interno.');
    }
}
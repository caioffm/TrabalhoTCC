<?php
header('Content-Type: application/json');

include 'connect.php';

// Removido a verificação de session_status() porque é esperado que o connect.php cuide da sessão.

if (isset($_SESSION['user']) && isset($_SESSION['user']['token'])) {
    echo json_encode(['logged_in' => true]);
    exit; // Adicionado o exit para prevenir execução adicional.
} else {
    echo json_encode(['logged_in' => false]);
    exit; // Adicionado o exit aqui também.
}
?>


<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}

$host = '127.0.0.1';
$user = 'root';
$pass = ''; // Considere usar uma senha segura e armazená-la de forma segura
$database = 'padaria';

$mysqli = mysqli_connect($host, $user, $pass, $database);

if(mysqli_connect_errno()){
    echo json_encode(['error' => 'Erro ao conectar ao banco de dados: ' . mysqli_connect_error()]);
    exit; // Encerre o script após encontrar um erro de conexão
}
?>

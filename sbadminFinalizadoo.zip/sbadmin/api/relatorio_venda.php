<?php

include 'private/connect.php'; 

// Comece com a base da sua query
$queryBase = "
SELECT 
    v.id AS venda_id,
    u.nome AS nome_usuario,
    DATE_FORMAT(v.data_da_venda, '%d/%m/%Y') AS data_formatada,
    dv.quantidade,
    dv.preco_de_venda,
    p.unidade_de_medida,
    p.nome AS nome_produto,
    c.nome AS nome_cupom,
    IFNULL(c.desconto, 0) AS desconto_cupom_percentual,
    (dv.preco_de_venda * dv.quantidade) * IFNULL(c.desconto, 0) / 100 AS desconto_reais,
    (dv.preco_de_venda * dv.quantidade) - ((dv.preco_de_venda * dv.quantidade) * IFNULL(c.desconto, 0) / 100) AS valor_total_venda
FROM 
    vendas v
LEFT JOIN usuarios u ON v.usuario_id = u.id
LEFT JOIN detalhes_vendas dv ON v.id = dv.venda_id
LEFT JOIN produtos p ON dv.produto_id = p.id
LEFT JOIN cupons c ON v.cupom_id = c.id
";

$clausulasWhere = [];
$parametros = [];
$tipos = "";

// Verifique se os filtros foram enviados e os adicione às cláusulas WHERE
if (isset($_GET['nomeProduto']) && $_GET['nomeProduto'] !== '') {
    $clausulasWhere[] = "p.nome LIKE ?";
    $parametros[] = "%" . $_GET['nomeProduto'] . "%";
    $tipos .= "s";
}

if (isset($_GET['dataVenda']) && $_GET['dataVenda'] !== '') {
    $clausulasWhere[] = "DATE(v.data_da_venda) = ?";
    $parametros[] = $_GET['dataVenda'];
    $tipos .= "s";
}

if (isset($_GET['nomeUsuario']) && $_GET['nomeUsuario'] !== '') {
    $clausulasWhere[] = "u.nome LIKE ?";
    $parametros[] = "%" . $_GET['nomeUsuario'] . "%";
    $tipos .= "s";
}

// Adicione as cláusulas WHERE se houverem
if (count($clausulasWhere) > 0) {
    $queryBase .= " WHERE " . implode(" AND ", $clausulasWhere);
}

// Adicione a cláusula ORDER BY ao final da consulta
$queryBase .= " ORDER BY v.id DESC;";

// Preparar e vincular parâmetros
$stmt = $mysqli->prepare($queryBase);

// Apenas chame bind_param se houver parâmetros
if ($tipos && count($parametros)) {
    $stmt->bind_param($tipos, ...$parametros);
}

$stmt->execute();
$resultado = $stmt->get_result();

$dados = [];
while ($linha = $resultado->fetch_assoc()) {
    $dados[] = $linha;
}

echo json_encode($dados);

?>

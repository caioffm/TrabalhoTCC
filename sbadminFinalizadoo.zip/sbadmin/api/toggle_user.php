<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php"; // Inclua o arquivo de conexão

if (isset($_GET['id']) && isset($_GET['ativo'])) {
    $id = $_GET['id'];
    $ativo = $_GET['ativo'];

    $query = "UPDATE usuarios SET ativo=$ativo WHERE id=$id";

    if (mysqli_query($mysqli, $query)) {
        $response = array(
            'status' => 200, 
            'msg' => 'Usuário ' . ($ativo ? 'ativado' : 'desativado') . ' com sucesso.',
            'newStatus' => $ativo // Retorna o novo status
        );
    } else {
        $response = array('status' => 500, 'msg' => 'Erro ao atualizar o usuário: ' . mysqli_error($mysqli));
    }
} else {
    $response = array('status' => 400, 'msg' => 'ID de usuário ou status ativo não fornecido.');
}

echo json_encode($response);

mysqli_close($mysqli);
?>

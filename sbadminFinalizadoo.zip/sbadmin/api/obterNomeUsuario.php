<?php
header('Content-Type: application/json');

include 'private/connect.php';


if (session_status() == PHP_SESSION_NONE) {
    session_start();
}



if (isset($_SESSION['nome'])) {
    echo json_encode(['nome' => $_SESSION['nome']]);
} else {
    echo json_encode(['nome' => 'Não identificado']);
}
?>

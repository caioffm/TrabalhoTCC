<?php
include 'private/connect.php';

$ano = isset($_GET['ano']) ? $_GET['ano'] : date("Y");
$mes = isset($_GET['mes']) ? $_GET['mes'] : null;
$dia = isset($_GET['dia']) ? $_GET['dia'] : null;

$where = [];

if ($ano) {
    $where[] = "YEAR(v.data_da_venda) = $ano";
}
if ($mes) {
    $where[] = "MONTH(v.data_da_venda) = $mes";
}
if ($dia) {
    $where[] = "DAY(v.data_da_venda) = $dia";
}

$where_sql = implode(' AND ', $where);
$where_sql = !empty($where_sql) ? "WHERE " . $where_sql : '';

$query_data = "
SELECT
    v.id AS venda_id,
    DATE_FORMAT(v.data_da_venda, '%d/%m/%Y') AS data_da_venda,
    p.nome AS Produto,
    dv.quantidade AS quantidade_vendida,
    dv.preco_de_venda AS preco_de_venda_unidade,
    p.preco_de_custo AS preco_de_compra_unidade,
    ((dv.preco_de_venda - p.preco_de_custo) * dv.quantidade) AS lucro_total
FROM
    vendas v
LEFT JOIN detalhes_vendas dv ON v.id = dv.venda_id
LEFT JOIN produtos p ON dv.produto_id = p.id
$where_sql
";

$result_data = $mysqli->query($query_data);
$data = [];
while ($row = $result_data->fetch_assoc()) {
    $data[] = $row;
}

$query_total = "
SELECT SUM((dv.preco_de_venda - p.preco_de_custo) * dv.quantidade) AS lucro_total
FROM
    vendas v
LEFT JOIN detalhes_vendas dv ON v.id = dv.venda_id
LEFT JOIN produtos p ON dv.produto_id = p.id
$where_sql
";

$result_total = $mysqli->query($query_total);
$row_total = $result_total->fetch_assoc();
$lucroTotal = $row_total['lucro_total'] ?? 0;

$response = [
    'data' => $data,
    'lucroTotal' => $lucroTotal
];

echo json_encode($response);
?>

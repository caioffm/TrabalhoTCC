<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include "private/connect.php";


$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $nomeCupom = $data['nome_cupom'] ?? null;

    if (!$nomeCupom) {
        $response['status'] = 400;
        $response['message'] = "Nome do cupom não fornecido.";
    } else {
        $stmt = $mysqli->prepare("SELECT * FROM cupons WHERE nome = ? AND ativo = TRUE");
        $stmt->bind_param("s", $nomeCupom);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            $response['status'] = 404;
            $response['message'] = "Cupom não encontrado ou não está ativo.";
        } else {
            $cupom = $result->fetch_assoc();
            $response['status'] = 200;
            $response['cupom'] = $cupom;
        }
    }
} else {
    $response['status'] = 405;
    $response['message'] = "Método não permitido";
}

header('Content-Type: application/json');
echo json_encode($response);

$mysqli->close();
?>
